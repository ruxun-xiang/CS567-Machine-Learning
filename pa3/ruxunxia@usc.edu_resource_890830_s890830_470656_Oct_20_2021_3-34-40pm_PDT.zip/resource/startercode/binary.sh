python3 -W ignore classification.py --type binary --output binary.out
rm -rf __pycache__
